@include('admin.include.header')
	@yield('style')
    @yield('content')
@include('admin.include.footer')
@yield('script')

