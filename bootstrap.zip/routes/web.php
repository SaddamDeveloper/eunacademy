<?php
require __DIR__ . '/frontend.php';
require __DIR__ . '/admin.php';
require __DIR__ . '/branch.php';
