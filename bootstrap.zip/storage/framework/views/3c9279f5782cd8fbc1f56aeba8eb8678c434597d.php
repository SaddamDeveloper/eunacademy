    <?php $__env->startSection('seo'); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
        <!-- start of page-header -->
        <section class="page-header bg-cover has-overlay" style="background-image: url(assets/images/page-header-02.jpg)">
            <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="section-title text-white font-weight-bold mb-20">Contact</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb bg-transparent justify-content-center p-0 font-weight-600 mb-0">
                        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('web.index')); ?>">Home</a></li>
                        <li class="breadcrumb-item">Contact</li>
                        </ol>
                    </nav>
                </div>
            </div>
            </div>
        </section>
        <!-- end of page-header -->        
        
        <!-- start of contact section -->
        <section class="section-padding bg-gray">
            <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-7 order-1 order-lg-0">
                    <div class="mb-5">
                        <h2 class="text-secondary font-weight-bold mb-2">Send a Message</h2>
                        <p>Your email address will not be published. <br> Required fields are marked.</p>
                    </div>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" ><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                    <?php endif; ?>
                    <?php echo e(Form::open(['method' => 'post','route'=>'web.store.contact'])); ?>

                        <div class="row">
                        <div class="col-md-6">
                            <div class="mb-30">
                                <label for="name">Name*</label>
                                <input type="text" class="form-control rounded-sm" name="name" value="<?php echo e(old('name')); ?>" id="name" placeholder="Jack Barker">
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert" style="color:red">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-30">
                                <label for="email">Email*</label>
                                <input type="email" class="form-control rounded-sm" name="email" value="<?php echo e(old('email')); ?>" id="email" placeholder="jack@email.com">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert" style="color:red">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-30">
                                <label for="sub">Subject</label>
                                <input type="text" class="form-control rounded-sm" id="subject" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="I want to know about course.">
                                <?php if($errors->has('subject')): ?>
                                    <span class="invalid-feedback" role="alert" style="color:red">
                                        <strong><?php echo e($errors->first('subject')); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-30">
                                <label for="message">Message</label>
                                <textarea class="form-control rounded-sm" id="message" name="message" rows="5"><?php echo e(old('message')); ?></textarea>
                                <?php if($errors->has('message')): ?>
                                    <span class="invalid-feedback" role="alert" style="color:red">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary rounded-sm">Send Message</button>
                        </div>
                        </div>
                    </form>
                </div>
        
                <div class="col-xl-4 col-lg-5 mb-5 mb-lg-0 order-0 order-lg-1">
                    <div class="mb-5">
                        <h2 class="text-secondary font-weight-bold mb-2">Contact Info</h2>
                        <p>Welcome to our Website. <br> We are glad to have you around.</p>
                    </div>
                    <div class="shadow-sm p-20 mt-4 rounded-sm bg-white d-block d-sm-flex align-items-center">
                        <i class="fas fa-phone fa-2x text-primary"></i>
                        <div class="ml-sm-4 mt-3 mt-sm-0">
                            <h4 class="text-secondary font-weight-600 mb-1">Phone</h4>
                            <p>Phone: <a href="tel:+7800123452" class="text-dark">+91 86382 57498</a></p>
                        </div>
                    </div>
                    <div class="shadow-sm p-20 mt-4 rounded-sm bg-white d-block d-sm-flex align-items-center">
                        <i class="fas fa-map-marked-alt fa-2x text-primary"></i>
                        <div class="ml-sm-4 mt-3 mt-sm-0">
                            <h4 class="text-secondary font-weight-600 mb-1">Location</h4>
                            <p>Assam</p>
                        </div>
                    </div>
                    <div class="shadow-sm p-20 mt-4 rounded-sm bg-white d-block d-sm-flex align-items-center">
                        <i class="fas fa-envelope fa-2x text-primary"></i>
                        <div class="ml-sm-4 mt-3 mt-sm-0">
                            <h4 class="text-secondary font-weight-600 mb-1">Email</h4>
                            <p>Mail: <a href="mailto:eunproaca@gmail.com" class="text-dark">eunproaca@gmail.com</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of contact section -->

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?> 

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('web.templete.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\eunacademy\resources\views/web/contact.blade.php ENDPATH**/ ?>